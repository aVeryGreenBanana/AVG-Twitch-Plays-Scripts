# Original Written by DougDoug and DDarknut
# Current iteration written by aVeryGreenBanana

# Hello! This file contains the main logic to process Twitch chat and convert it to game commands.
# The code is written in Python 3.X
# There are 2 other files needed to run this code:
    # TwitchPlays_KeyCodes.py contains the key codes and functions to press keys in-game. You should not modify this file.
    # TwitchPlays_Connection.py is the code that actually connects to Twitch. You should not modify this file.

# The source code primarily comes from:
    # Wituz's "Twitch Plays" tutorial: http://www.wituz.com/make-your-own-twitch-plays-stream.html
    # PythonProgramming's "Python Plays GTA V" tutorial: https://pythonprogramming.net/direct-input-game-python-plays-gta-v/
    # DDarknut's message queue and updates to the Twitch networking code

# Disclaimer: 
    # This code is NOT intended to be professionally optimized or organized.
    # We created a simple version that works well for livestreaming, and I'm sharing it for educational purposes.

##########################################################

TWITCH_CHANNEL = 'averygreenbanana' # Replace this with your Twitch username. Must be all lowercase.

##########################################################
# import re
import pyttsx3 #tts library        #TTS CHANGES        pip install pyttsx3
import statistics as s
import TwitchPlays_Connection
import pyautogui
import random
import keyboard
from collections import Counter
import concurrent.futures
from TwitchPlays_KeyCodes import *

##########################################################

# MESSAGE_RATE controls how fast we process incoming Twitch Chat messages. It's the number of seconds it will take to handle all messages in the queue.
# This is used because Twitch delivers messages in "batches", rather than one at a time. So we process the messages over MESSAGE_RATE duration, rather than processing the entire batch at once.
# A smaller number means we go through the message queue faster, but we will run out of messages faster and activity might "stagnate" while waiting for a new batch. 
# A higher number means we go through the queue slower, and messages are more evenly spread out, but delay from the viewers' perspective is higher.
# You can set this to 0 to disable the queue and handle all messages immediately. However, then the wait before another "batch" of messages is more noticeable.
MESSAGE_RATE = 0.5
# MAX_QUEUE_LENGTH limits the number of commands that will be processed in a given "batch" of messages. 
# e.g. if you get a batch of 50 messages, you can choose to only process the first 10 of them and ignore the others.
# This is helpful for games where too many inputs at once can actually hinder the gameplay.
# Setting to ~50 is good for total chaos, ~5-10 is good for 2D platformers
MAX_QUEUE_LENGTH = 50  
MAX_WORKERS = 100 # Maximum number of threads you can process at a time 

# lists
listOfMessages = []
listOfChatters = []

#boolean variables (true or false stuff)
pollWorking = False;
pollCanStart = True;                # helps prevent multiple polls starting
isTalking = False;
ReturnDeezNutz = True;                # set this to false if you dont want deez nutz TTS


last_time = time.time()
message_queue = []
thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS)
active_tasks = []
pyautogui.FAILSAFE = False

##########################################################

# An optional count down before starting, so you have time to load up the game
countdown = 3
while countdown > 0:
    print(countdown)
    countdown -= 1
    time.sleep(1)

t = TwitchPlays_Connection.Twitch();
t.twitch_connect(TWITCH_CHANNEL);

def handle_message(message):
    try:
        msg = message['message'].lower()
        username = message['username'].lower()

        # lets you view who is sending each message, set displayMessage to true if you want to see this
        displayMessage = False;
        if displayMessage == True:
            print("Got the message: [" + msg + "] from user [" + username + "]")         

        ###################################
        # Code Section 
        ###################################

        # reads in variables from above
        global listOfMessages;
        global listOfChatters;
        global pollWorking;     #helps prevent multiple polls starting
        global pollCanStart;    #mods can control
        global isTalking;       #deez nutz
        global text_speech;     #TTS CHANGES

        text_speech = pyttsx3.init() #initializes text to speech on start     #TTS CHANGES

        if text_speech._inLoop:      #TTS CHANGES
            text_speech.endLoop()    #TTS CHANGES       

        #List of mods in your chat (include your name in this list)
        listOfMods = [TWITCH_CHANNEL,'replace_This_Text_With_Mod_Names_But_Keep_Apostrophe1', 'replace_This_Text_With_Mod_Names_But_Keep_Apostrophe2', 'replace_This_Text_With_Mod_Names_But_Keep_Apostrophe3'];

        # controls WHO starts the poll and using WHAT keyword
        if username in listOfMods: #checks that only your mods and yourself can start poll
            #print("Hi me!"); # program says hi to you if its you
            if msg == "start":
                if pollCanStart == True and isTalking == False:  # helps prevent multiple polls starting
                    pollCanStart = False; # helps prevent multiple polls starting                                  
                    pollWorking = True;    
                    isTalking == True;      #deez nutz
                    answer = 'The poll is now open, please type in your answer'                          # what tts says       #TTS CHANGES
                    text_speech.say(answer) # tells tts to say the statement above                                             #TTS CHANGES
                    text_speech.runAndWait() # tells tts to stop talking                                                       #TTS CHANGES            
                else: # helps prevent multiple polls starting
                    print("There is a poll already open"); # helps prevent multiple polls starting

        ###################################
        # DEEZ NUTZ Section
        ###################################

        # reads in variables from above
        global ReturnDeezNutz;  #deez nutz


        #if you dont care for TTS returning deez nutz jokes, then put a # next to the start of each line which has #deeznutz at the end
        if ReturnDeezNutz == True:                                                                                                              #DEEZ NUTZ
            if isTalking == False:                                                                                                              #DEEZ NUTZ
                if "bofa" in msg.lower():                                                                                                       #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Bopha dees nuts in your mouth" # what tts says                                             #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ
                    isTalking = False;                                                                                                          #DEEZ NUTZ

                if "norway" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Norway dees nuts fit in your mouth" # what tts says                                        #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                
                if "cd" in msg.lower():                                                                                                         #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Why dont you see dees nuts" # what tts says                                                #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ

                if "ligma" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". ligma balls" # what tts says                                                               #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                
                if "goblin" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". gobbling dees nuts" # what tts says                                                        #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "dragon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". dragon deez nuts across your face" # what tts says                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "wendy" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". when deez nutz hit your face" # what tts says                                              #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "landon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". landon deez nutz" # what tts says                                                          #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "kenya" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". kenya fit dees nuts in your mouth" # what tts says                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "suggon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". suck on dees nuts" # what tts says                                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "candice" in msg.lower():                                                                                                    #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". candice nutz fit in your mouth?" # what tts says                                           #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ

                if "dqw4w9wgxcq" in msg.lower():                                                                                                #Rick Roll
                    isTalking = True;                                                                                                           #Rick Roll
                    print("Hey "  + username)                                                                                                   #Rick Roll
                    answer = "Hey "  + username + ". I'm never gonna give you up" # what tts says                                               #Rick Roll
                    text_speech.say(answer) # tells tts to say the statement above                                                              #Rick Roll
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #Rick Roll
                    isTalking = False;                                                                                                          #Rick Roll

        if msg == "stop tts" and username in listOfMods:
            ReturnDeezNutz = False
            print("TTS is disabled")

        if msg == "start tts" and username in listOfMods:
            ReturnDeezNutz = True
            print("TTS is enabled")

        ####################################
        ####################################


        # Adds messages to a list     
        if pollWorking == True:
            print("true")
            if username not in listOfChatters:
                if msg == "start" and username in listOfMods:
                    listOfChatters.remove(username)
                print("working")
                listOfChatters.append(username)
                listOfMessages.append(msg)

        # lets you end the poll by checking that you wrote "tally" and that the user matches channel name
        if username in listOfMods: #checks that only your mods and yourself can end poll
            #print("Hi me!"); # program says hi to you if its you
            if msg == "tally":                     
                if pollWorking == True:
                    #### show what was voted upon and what won
                    tempList = [s for s in listOfMessages if s != 'start' and s != 'tally']
                    if tempList:
                        print("All Results:", tempList)
                        print("Most voted result(s):", s.multimode(tempList))
                        shortList= s.multimode(tempList)
                        winningResult = random.choice(shortList)
                        print("Winning result is:", winningResult)
                    else:                                           # in case no votes occur
                        winningResult = "You're too slow!"          # in case no votes occur
                        print(winningResult)                        # in case no votes occur
                else:
                    print("No poll open to tally")

                #### TTS For winning result
                answer = "The result that won is: " + winningResult # what tts says                                                   
                text_speech.say(answer) # tells tts to say the statement above                                                              
                text_speech.runAndWait() # tells tts to stop talking                                                                         
                isTalking = False;    

                pollWorking = False;
                listOfMessages.clear();
                listOfChatters.clear();
                pollCanStart = True;        #helps prevent multiple polls starting


            elif msg == "tally top 3":
                tempList2 = [s for s in listOfMessages if s != 'start' and s != 'tally' and s != ' ']
                if tempList2:
                    Elements_with_frequency = Counter(tempList2)
                    # stringFindNum == msg
                    # numberToTallied = int(re.search(r'\d+', stringFindNum).group())
                    # print("The top 3 results with their votes were:", Elements_with_frequency.most_common(numberToTallied))
                    # top3List = Elements_with_frequency.most_common(numberToTallied)
                    print("The top 3 results with their votes were:", Elements_with_frequency.most_common(3))
                    top3List = Elements_with_frequency.most_common(3)
                    firstResult = str(top3List[0][0]) + " had " + str(top3List[0][1]) + " votes"
                    secondResult = str(top3List[1][0]) + " had " + str(top3List[1][1]) + " votes"
                    thirdResult = str(top3List[2][0]) + " had " + str(top3List[2][1]) + " votes"
                    winningResult = firstResult + secondResult + thirdResult
                else:                                           # in case no votes occur
                    winningResult = "You're too slow!"          # in case no votes occur
                    print(winningResult)                        # in case no votes occur

                #### TTS For winning result
                answer = "The top 3 results are as follows: " + winningResult                                                   
                text_speech.say(answer) # tells tts to say the statement above                                                              
                text_speech.runAndWait() # tells tts to stop talking                                                                         
                isTalking = False;    

                pollWorking = False;
                listOfMessages.clear();
                listOfChatters.clear();
                pollCanStart = True;        #helps prevent multiple polls starting



        ####################################
        ####################################

    except Exception as e:
        print("Encountered exception: " + str(e))


while True:

    active_tasks = [t for t in active_tasks if not t.done()]

    #Check for new messages
    new_messages = t.twitch_receive_messages();
    if new_messages:
        message_queue += new_messages; # New messages are added to the back of the queue
        message_queue = message_queue[-MAX_QUEUE_LENGTH:] # Shorten the queue to only the most recent X messages

    messages_to_handle = []
    if not message_queue:
        # No messages in the queue
        last_time = time.time()
    else:
        # Determine how many messages we should handle now
        r = 1 if MESSAGE_RATE == 0 else (time.time() - last_time) / MESSAGE_RATE
        n = int(r * len(message_queue))
        if n > 0:
            # Pop the messages we want off the front of the queue
            messages_to_handle = message_queue[0:n]
            del message_queue[0:n]
            last_time = time.time();

    # If user presses Shift+Backspace, automatically end the program
    if keyboard.is_pressed('shift+backspace'):
        exit()

    if not messages_to_handle:
        continue
    else:
        for message in messages_to_handle:
            if len(active_tasks) <= MAX_WORKERS:
                active_tasks.append(thread_pool.submit(handle_message, message))
            else:
                print(f'WARNING: active tasks ({len(active_tasks)}) exceeds number of workers ({MAX_WORKERS}). ({len(message_queue)} messages in the queue)')
