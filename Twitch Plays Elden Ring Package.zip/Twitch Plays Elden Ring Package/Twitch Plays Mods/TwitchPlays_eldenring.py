# Original Written by DougDoug and DDarknut
# Current iteration written by aVeryGreenBanana

# Hello! This file contains the main logic to process Twitch chat and convert it to game commands.
# The code is written in Python 3.X
# There are 2 other files needed to run this code:
    # TwitchPlays_KeyCodes.py contains the key codes and functions to press keys in-game. You should not modify this file.
    # TwitchPlays_Connection.py is the code that actually connects to Twitch. You should not modify this file.

# The source code primarily comes from:
    # Wituz's "Twitch Plays" tutorial: http://www.wituz.com/make-your-own-twitch-plays-stream.html
    # PythonProgramming's "Python Plays GTA V" tutorial: https://pythonprogramming.net/direct-input-game-python-plays-gta-v/
    # DDarknut's message queue and updates to the Twitch networking code

# Disclaimer: 
    # This code is NOT intended to be professionally optimized or organized.
    # We created a simple version that works well for livestreaming, and I'm sharing it for educational purposes.

##########################################################

TWITCH_CHANNEL = 'averygreenbanana' # Replace this with your Twitch username. Must be all lowercase.    **edit this line**

##########################################################
import pyttsx3 #tts library        #TTS CHANGES        pip install pyttsx3
import keyboard
import TwitchPlays_Connection
import pydirectinput
import random
import pyautogui
import concurrent.futures
from TwitchPlays_KeyCodes import *

##########################################################

# MESSAGE_RATE controls how fast we process incoming Twitch Chat messages. It's the number of seconds it will take to handle all messages in the queue.
# This is used because Twitch delivers messages in "batches", rather than one at a time. So we process the messages over MESSAGE_RATE duration, rather than processing the entire batch at once.
# A smaller number means we go through the message queue faster, but we will run out of messages faster and activity might "stagnate" while waiting for a new batch. 
# A higher number means we go through the queue slower, and messages are more evenly spread out, but delay from the viewers' perspective is higher.
# You can set this to 0 to disable the queue and handle all messages immediately. However, then the wait before another "batch" of messages is more noticeable.
MESSAGE_RATE = 0.5
# MAX_QUEUE_LENGTH limits the number of commands that will be processed in a given "batch" of messages. 
# e.g. if you get a batch of 50 messages, you can choose to only process the first 10 of them and ignore the others.
# This is helpful for games where too many inputs at once can actually hinder the gameplay.
# Setting to ~50 is good for total chaos, ~5-10 is good for 2D platformers
MAX_QUEUE_LENGTH = 10  
MAX_WORKERS = 100 # Maximum number of threads you can process at a time 

# counts number of times each action is performed     
ReturnDeezNutz = True;                # set this to false if you dont want deez nutz TTS
isTalking = False;
takeCommands = True;


last_time = time.time()
message_queue = []
thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS)
active_tasks = []
pyautogui.FAILSAFE = False

##########################################################

# An optional count down before starting, so you have time to load up the game
countdown = 3
while countdown > 0:
    print(countdown)
    countdown -= 1
    time.sleep(1)

t = TwitchPlays_Connection.Twitch();
t.twitch_connect(TWITCH_CHANNEL);

def handle_message(message):
    try:
        msg = message['message'].lower()
        username = message['username'].lower()

        #List of mods in your chat. This is here in case you need to turn off TTS or inputs and cant for whatever reason in the moment, so it lets mods put a hold
        listOfMods = [TWITCH_CHANNEL, 'modNameHere', 'mod2NameHere']; #keep adding mod names to add the rest of your mods if you'd like   ***EDIT THIS LINE

        # lets you view who is sending each message, set displayMessage to true if you want to see this
        displayMessage = False;
        if displayMessage == True:
            print("Got the message: [" + msg + "] from user [" + username + "]")
        global takeCommands;

        ###################################
        # Control Code Section
        ####################################
        if msg == "enable commands" and username in listOfMods:
            takeCommands = True
            print("commands now working")

        if msg == "disable commands" and username in listOfMods:
            takeCommands = False
            print("commands now NOT WORKING")

        if takeCommands == True:
            # If the chat message is "left", then hold down the A key for 2 seconds
            if msg == "left": 
                ReleaseKey(D)
                HoldAndReleaseKey(A, 2)

            # If the chat message is "right", then hold down the D key for 2 seconds
            if msg == "right": 
                ReleaseKey(A)
                HoldAndReleaseKey(D, 2)
            
            # If the chat message is "forward", then hold down the D key for 2 seconds    
            if msg == "forward":
                ReleaseKey(S)
                HoldAndReleaseKey(W, 2)
            
            # If the chat message is "backward", then hold down the D key for 2 seconds    
            if msg == "backward":
                ReleaseKey(W)
                HoldAndReleaseKey(S, 2)
            
            # If the chat message is "stop", then release all keys   
            if msg == "stop":
                ReleaseKey(W)                
                ReleaseKey(LEFT_SHIFT)
                ReleaseKey(A)
                ReleaseKey(S)
                ReleaseKey(D)
        
            # If the chat message is "sprint", then same as forward but hold shift
            if msg == "sprint":
                ReleaseKey(S)
                HoldKey(W)
                HoldKey(SPACE)
                time.sleep(2)
                ReleaseKey(W)
                ReleaseKey(SPACE)

            # If the chat message is "backstep", then tap space
            if msg == "backstep":
                HoldAndReleaseKey(SPACE, 0.2)

            # If the chat message is "lroll", then hold down the A key and space for 0.2 seconds
            if msg == "lroll": 
                ReleaseKey(D)
                HoldAndReleaseKey(A, 0.2)
                HoldAndReleaseKey(SPACE, 0.2)

            # If the chat message is "rroll", then hold down the D key and space for 0.2 seconds
            if msg == "rroll": 
                ReleaseKey(A)
                HoldAndReleaseKey(D, 0.2)
                HoldAndReleaseKey(SPACE, 0.2)
            
            # If the chat message is "froll", then hold down the W key and space for 0.2 seconds   
            if msg == "froll":
                ReleaseKey(S)
                HoldAndReleaseKey(W, 0.2)
                HoldAndReleaseKey(SPACE, 0.2)
            
            # If the chat message is "broll", then hold down the S key and space for 0.2 seconds   
            if msg == "broll":
                ReleaseKey(W)
                HoldAndReleaseKey(S, 0.2)
                HoldAndReleaseKey(SPACE, 0.2)
                
            # If the chat message is "jump", then hold down the F key for 0.1 seconds
            if msg == "jump":
                HoldAndReleaseKey(F, 0.1)
                
            # If the chat message is "crouch", then hold down the X key for 1 seconds
            if msg == "crouch":
                HoldAndReleaseKey(X, 1)
        
            # If the chat message is "lock on", then hold down the Q key for 0.2 seconds
            if msg == "lock on":
                HoldAndReleaseKey(Q, 0.2)
        
            # If the chat message is "use item", then generate a random number between 1 and 50, if result is 29 hold down the R key for 0.2 seconds
            if msg == "use item":
                x = random.randint(1,50)
                if x == 29:
                    HoldAndReleaseKey(R, 0.2)
        
            # If the chat message is "light", then hold down the left mouse button for 0.2 seconds
            if msg == "light":
                pydirectinput.mouseDown(button="left")
                time.sleep(0.2)
                pydirectinput.mouseUp(button="left")
                
            # If the chat message is "heavy", then hold down the left mouse button and shift for 0.5 seconds
            if msg == "heavy":
                HoldAndReleaseKey(LEFT_SHIFT, 0.5)
                pydirectinput.mouseDown(button="left")                
                time.sleep(0.5)
                pydirectinput.mouseUp(button="left")
        
            # If the chat message is "guard", then hold down the right mouse button for 0.2 seconds
            if msg == "guard":
                pydirectinput.mouseDown(button="right")
                time.sleep(0.5)
                pydirectinput.mouseUp(button="right")
                
            # If the chat message is "skill", then hold down the right mouse button and shift for 0.5 seconds
            if msg == "skill":
                HoldKey(LEFT_SHIFT)
                pydirectinput.mouseDown(button="right")
                time.sleep(0.5)
                pydirectinput.mouseUp(button="right")
                ReleaseKey(LEFT_SHIFT)
        
            # If the chat message is "interact", then hold down the E key for 0.5 seconds
            if msg == "interact":
                HoldAndReleaseKey(E, 0.5)

            # If the chat message is "switch item", then hold down '2' key for 0.2 seconds
            if msg == "switch item":
                HoldAndReleaseKey(TWO, 0.2)                     # ** EDIT THIS LINE, CHANGE CONTROL IN GAME TO 2
        else:
            print("commands not working, try typing 'enable commands' into twitch chat")
       
        ###################################
        # TTS Section
        ###################################

        # reads in variables from above
        global ReturnDeezNutz;  #deez nutz
        global isTalking;       #deez nutz
        global text_speech;     #TTS CHANGES

        text_speech = pyttsx3.init() #initializes text to speech on start     #TTS CHANGES

        if text_speech._inLoop:      #TTS CHANGES
            text_speech.endLoop()    #TTS CHANGES


        #if you dont care for TTS returning deez nutz jokes, then put a # next to the start of each line which has #deeznutz at the end
        if ReturnDeezNutz == True:                                                                                                              #DEEZ NUTZ
            if isTalking == False:                                                                                                              #DEEZ NUTZ
                if "bofa" in msg.lower():                                                                                                       #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Bopha dees nuts in your mouth" # what tts says                                             #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ
                    isTalking = False;                                                                                                          #DEEZ NUTZ

                if "norway" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Norway dees nuts fit in your mouth" # what tts says                                        #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                
                if "cd" in msg.lower():                                                                                                         #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". Why dont you see dees nuts" # what tts says                                                #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ

                if "ligma" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". ligma balls" # what tts says                                                               #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                
                if "goblin" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". gobbling dees nuts" # what tts says                                                        #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "dragon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". dragon deez nuts across your face" # what tts says                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "wendy" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". when deez nutz hit your face" # what tts says                                              #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "landon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". landon deez nutz" # what tts says                                                          #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "kenya" in msg.lower():                                                                                                      #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". kenya fit dees nuts in your mouth" # what tts says                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "suggon" in msg.lower():                                                                                                     #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". suck on dees nuts" # what tts says                                                         #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ
                    
                if "candice" in msg.lower():                                                                                                    #DEEZ NUTZ
                    isTalking = True;                                                                                                           #DEEZ NUTZ
                    print("Hey "  + username)                                                                                                   #DEEZ NUTZ
                    answer = "Hey "  + username + ". candice nutz fit in your mouth?" # what tts says                                           #DEEZ NUTZ
                    text_speech.say(answer) # tells tts to say the statement above                                                              #DEEZ NUTZ
                    text_speech.runAndWait() # tells tts to stop talking                                                                        #DEEZ NUTZ 
                    isTalking = False;                                                                                                          #DEEZ NUTZ

        if msg == "stop tts" and username in listOfMods:
            ReturnDeezNutz = False
            print("TTS is disabled")

        if msg == "start tts" and username in listOfMods:
            ReturnDeezNutz = True
            print("TTS is enabled")

        ####################################
        ####################################

    except Exception as e:
        print("Encountered exception: " + str(e))


while True:

    active_tasks = [t for t in active_tasks if not t.done()]

    #Check for new messages
    new_messages = t.twitch_receive_messages();
    if new_messages:
        message_queue += new_messages; # New messages are added to the back of the queue
        message_queue = message_queue[-MAX_QUEUE_LENGTH:] # Shorten the queue to only the most recent X messages

    messages_to_handle = []
    if not message_queue:
        # No messages in the queue
        last_time = time.time()
    else:
        # Determine how many messages we should handle now
        r = 1 if MESSAGE_RATE == 0 else (time.time() - last_time) / MESSAGE_RATE
        n = int(r * len(message_queue))
        if n > 0:
            # Pop the messages we want off the front of the queue
            messages_to_handle = message_queue[0:n]
            del message_queue[0:n]
            last_time = time.time();

    # If user presses Shift+Backspace, automatically end the program
    if keyboard.is_pressed('shift+backspace'):
        exit()

    if not messages_to_handle:
        continue
    else:
        for message in messages_to_handle:
            if len(active_tasks) <= MAX_WORKERS:
                active_tasks.append(thread_pool.submit(handle_message, message))
            else:
                print(f'WARNING: active tasks ({len(active_tasks)}) exceeds number of workers ({MAX_WORKERS}). ({len(message_queue)} messages in the queue)')
